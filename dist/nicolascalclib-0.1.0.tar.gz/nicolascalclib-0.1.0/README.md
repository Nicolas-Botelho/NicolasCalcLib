# Nicolas Calc Lib
Biblioteca com as Operações de uma Calculadora em Python

## Operações Suportadas
- soma: Soma
- subs: Subtração
- mult: Multiplicação
- divs: Divisão
- powX: Potência
- pow2: Potência de 2
- raiz: Raiz
- rzqd: Raiz Quadrada
